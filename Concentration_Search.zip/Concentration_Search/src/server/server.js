const http = require('http');
const url = require('url');
const fs = require('fs');
const path = require('path');
const firebaseAdmin = require('firebase-admin');

const serviceAccount = require('../../firebase-adminsdk.json')

firebaseAdmin.initializeApp({
    credential: firebaseAdmin.credential.cert(serviceAccount)
  });

const mimeTypes = {
'.html': 'text/html',
'.js': 'text/javascript',
'.css': 'text/css',
};

const firestore = firebaseAdmin.firestore();

async function searchConcentrations(query) {
    const concentrationList = await firestore.collection("concentration").get();
    const concentrationMatches = [];
  
    concentrationList.forEach(doc => {
      const conData = doc.data();
      const docIDL = doc.id.toLowerCase();
      const docID = doc.id;
      if(docIDL.includes(query.toLowerCase())) {
        concentrationMatches.push(({ ...conData, docID }));
      }
    });
  
    return concentrationMatches;
  }


const server = http.createServer(async (req, res) => {
    const queryObject = url.parse(req.url, true).query;
  
    if (req.url.startsWith('/search')) {
      const searchQuery = queryObject.q;
      if (searchQuery) {
        try {
          const results = await searchConcentrations(searchQuery);
          res.writeHead(200, {'Content-Type': 'application/json'});
          res.end(JSON.stringify(results));
        } catch (error) {
          console.error(error);
          res.writeHead(500);
          res.end(JSON.stringify({error: 'Internal Server Error'}));
        }
      } else {
        res.writeHead(400);
        res.end(JSON.stringify({error: 'Bad Request'}));
      }
    } else {
        let filePath = path.join(__dirname, '../../public', req.url === '/' ? 'csearch.html' : req.url);
        const ext = path.extname(filePath);
        const contentType = mimeTypes[ext] || 'application/octet-stream';
    
        fs.readFile(filePath, (err, content) => {
          if (err) {
            if (err.code == 'ENOENT') {
              res.writeHead(404);
              res.end(JSON.stringify({error: 'Not Found'}));
            } else {
              res.writeHead(500);
              res.end(JSON.stringify({error: 'Internal Server Error'}));
            }
          } else {
            res.writeHead(200, {'Content-Type': contentType});
            res.end(content, 'utf-8');
          }
        });
    }
  });
  
  const PORT = 3000;
  server.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  module.exports = { searchConcentrations };
