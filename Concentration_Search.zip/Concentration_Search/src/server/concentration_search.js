export const filters = {
    "School": ["Business School", "Schools of Arts & Sciences", "School of Engineering", "School of Communication & Information"],
    "Credits": 120,
    "Degree Type": ["B.A", "B.S", "Minor"]

}

export function displayFiltrationOptions(filtrationBox) {
    filtrationBox.innerHTML = '';
    const createCheckBoxes = (filters, identifier) => {
        filters.forEach(filter => {
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.id = filter;
            checkbox.name = identifier;
            checkbox.value = filter;

            const label = document.createElement('label');
            label.htmlFor = filter;
            label.textContent = filter;

            filtrationBox.appendChild(checkbox);
            filtrationBox.appendChild(label);
            filtrationBox.appendChild(document.createElement('br'))
        })
    }

    createCheckBoxes(filters['School'], 'School')
    createCheckBoxes(filters['Degree Type'], 'Degree Type')
}
